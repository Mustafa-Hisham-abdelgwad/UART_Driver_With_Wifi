/***************************************************************************************/
/****************************  IMT School Training Center ******************************/
/***************************************************************************************/
/** This file is developed by IMT School training center, All copyrights are reserved **/
/***************************************************************************************/

#ifndef NVIC_CONFIGURATION_H_
#define NVIC_CONFIGURATION_H_

#endif /* NVIC_CONFIGURATION_H_ */
