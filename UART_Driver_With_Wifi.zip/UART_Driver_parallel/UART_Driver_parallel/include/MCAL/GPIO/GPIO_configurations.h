/*
 * GPIO_configurations.h
 *
 *  Created on: Jul 23, 2022
 *      Author: abdelrahmanhossam
 */

#ifndef GPIO_CONFIGURATIONS_H_
#define GPIO_CONFIGURATIONS_H_





#endif /* GPIO_CONFIGURATIONS_H_ */
