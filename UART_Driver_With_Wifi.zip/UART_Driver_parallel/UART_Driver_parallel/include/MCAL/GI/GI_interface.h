/*
 * GI_interface.h
 *
 *  Created on: Aug 15, 2022
 *      Author: abdelrahmanhossam
 */

#ifndef INCLUDE_MCAL_GI_GI_INTERFACE_H_
#define INCLUDE_MCAL_GI_GI_INTERFACE_H_



void MGI_voidEnable (void);
void MGI_voidDisable (void);

#endif /* INCLUDE_MCAL_GI_GI_INTERFACE_H_ */
