/*
 * GI_configuration.h
 *
 *  Created on: Aug 15, 2022
 *      Author: abdelrahmanhossam
 */

#ifndef INCLUDE_MCAL_GI_GI_CONFIGURATION_H_
#define INCLUDE_MCAL_GI_GI_CONFIGURATION_H_





#endif /* INCLUDE_MCAL_GI_GI_CONFIGURATION_H_ */
