/***************************************************************************************/
/****************************  IMT School Training Center ******************************/
/***************************************************************************************/
/** This file is developed by IMT School training center, All copyrights are reserved **/
/***************************************************************************************/

#include "../include/LIB/STD_TYPES.h"
#include "../include/LIB/BIT_MATH.h"
#include "../include/LIB/LIB.h"
#include "../include/MCAL/RCC/RCC_interface.h"
#include "../include/MCAL/GPIO/GPIO_interface.h"
#include "../include/MCAL/NVIC/NVIC_interface.h"
#include "../include/MCAL/SYSTICK/SYSTICK_interface.h"
#include "../include/MCAL/UART/UART_interface.h"

#include "../include/MCAL/GPIO/GPIO_private.h"
#include "../include/MCAL/GPIO/GPIO_configurations.h"


int main()
{
	// Configuration as HSI/2 --> 8 MHz
	MRCC_voidInit();
	// Set Systick Configuration
	MSYSTICk_voidConfig();
	// Enable GPIOA from RCC
	MRCC_voidPeripheralEnable(AHB1, GPIOAEN);
	// Enable USART1 from RCC
	MRCC_voidPeripheralEnable(APB2,USART1EN);
	// Configure USART1 Pins as Alternative Function Push Pull
	MGPIO_voidSetPinDirection(GPIOA_PORT, 9,  AF_PUSH_PULL, MEDIUM_SPEED);
	MGPIO_voidSetPinDirection(GPIOA_PORT, 10, AF_PUSH_PULL, MEDIUM_SPEED);
	// Set AF 7 for PA9 and PA10
	MGPIO_voidSetAF(GPIOA_PORT, PIN9,  7);
	MGPIO_voidSetAF(GPIOA_PORT, PIN10, 7);
	// Configuration of UART
	USART_InitType uart={115200,MODE_8BIT,STOP_BIT_1,DISABLE,EVEN_PARITY,TX_RX,DISABLE,OVER_SAMPLING_16};
	USART_ClockInitTypeDef uartclock ={DISABLE,0,0,0};
	// Initialization of USART1
	MUSART_voidInit(&uart, &uartclock, USART1);
	// Enable USART1
	MUSART_Enable(USART1);
	// Transmit String
//	MUSART_voidTransmitString(USART1, "AT\r\n");
	MUSART_voidTransmitByte('M');
	// Infinite loop
  while (1)
  {
    // Add your code here.
  }
}
