/*
 * ESP8266_program.c
 *
 *  Created on: Oct 13, 2022
 *      Author: mazen
 */


// NOTE: These realtive paths might not be correct, modify them according to your project
#include "STD_TYPES.h"
#include "UART_int.h"

volatile char recv_buffer[BUFFER_SIZE];
static u32 BufferIterator = 0;
u8 uart_flag = 0;

void UART_Callback(void)
{
	recv_buffer[BufferIterator] = UART_REadDataRgister();
	BufferIterator ++ ;


}

void ESP8266_vInit(void)
{
	UART_SetCallback(UART_Callback);
	UART_Init();

	// disable the Echo
	UART_SendString("ATE0\r\n");

	// set Mode: station+AccessPoint
	UART_SendString("AT+CWMODE=3\r\n");

}


void ESP8266_vConnectToAccessPoint(char* ssid, char* password)
{
	UART_SendString("AT+CWJAP_CUR=\"");
	UART_SendString(ssid);
	UART_sendString("\",\"");
	UART_SendString(password);
	UART_SendString("\"\r\n");

	// STK_busywaitdelay(5)
}


void ESP8266_vOpenServerTCPConnection(char* ServerIp, char* PortNo)
{
	UART_SendString("AT+CIPSTART=\"TCP\",\"");
	UART_SendString(ServerIp);
	UART_sendString("\",");
	UART_SendSting(PortNo);
	UART_SendSTring("\r\n");
}


void ESP8266_vSendHttpRequest(char* url, char* length)
{
	UART_SendString("AT+CIPSEND=");
	UART_SendString(length);
	UART_SendString("\r\n");

	// delay for 1 or 2  seconds if needed

	UART_SendString(url);
	UART_SendString("\r\n");
}











