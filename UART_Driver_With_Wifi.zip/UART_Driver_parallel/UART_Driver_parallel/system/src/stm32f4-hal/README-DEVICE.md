# stm32cube_fw_f4_v1252.zip

## STM32F4 HAL Drivers V1.7.10 / 22-October-2020

The `stm32f4xx_*.c` files were copied from the folder:

- `STM32Cube_FW_F4_V1.25.2/Drivers/STM32F4xx_HAL_Driver/Src`
